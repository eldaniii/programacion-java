package unidad2;

public class Tarea1_1 {
	public static void main(String[] args) {
		int n1=5;
		int n2=10;
		
		int suma = n1+n2;
		
		System.out.println("El resultado de la suma es "+suma);
	}
}
