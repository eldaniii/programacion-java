
package unidad3;

public class Tarea2_7 {
	public static void main(String[] args) {
		
	}
}
