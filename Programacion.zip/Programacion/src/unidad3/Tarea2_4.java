package unidad3;

import java.util.Scanner;

public class Tarea2_4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduce la frase:");
		String frase=sc.nextLine();
		
		for (int i=0; i<frase.length(); i++) {
			
		}
	}
}
