package u1ent;
import java.util.Scanner;

public class Ejercicio3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int nHamBasica=0;
		int nHamGourmet=0;
		double totalHamGourmet;
		double totalHamBasica;
		double precioBase=0;
		double precioFinal=0;
		double descuento=0;
		int perteneceClub;
		String dia;
		
		System.out.println("Pedidos Burbur");
		System.out.println("Introduzca el número de hamburgesas básicas:");
		nHamBasica=sc.nextInt();
		while (nHamBasica<0) {
			System.out.println("Número no válido. Elija el número de hamburgesas básicas:");
			nHamBasica=sc.nextInt();
		}
		System.out.println("Introduzca el número de hamburgesas gourmet:");
		nHamGourmet=sc.nextInt();
		while (nHamGourmet<0) {
			System.out.println("Número no válido. Elija el número de hamburgesas gourmet:");
			nHamGourmet=sc.nextInt();
		}
		System.out.println("Introduzca el día de la semana en MAYÚSCULAS y SIN tildes:");
		dia=sc.next();
		System.out.println("¿Pertenece al club Fanegas? (SI/NO):");
		System.out.println("1 - SI");
		System.out.println("2 - NO");
		perteneceClub=sc.nextInt();
		
		switch (dia) {
		case "MARTES": totalHamGourmet=(((nHamGourmet/2)*2)*4.5)+(nHamGourmet%2)*5; //Con esto en el primer paréntesis hacemos el pack doble y el resto por separado.
		totalHamBasica=nHamBasica*3;
		break;
		case "MIERCOLES": totalHamGourmet=nHamGourmet*5;;
		totalHamBasica=nHamBasica*2;
		break;
		default: totalHamGourmet=nHamGourmet*5;;
		totalHamBasica=nHamBasica*3;
		}
		
		precioBase=(totalHamBasica+totalHamGourmet);
		if (perteneceClub==1) descuento=(precioBase*12)/100;
		else descuento=0;
		precioFinal=precioBase-descuento;
		
		System.out.println("Aquí tiene su pedido gracias por su compra");
		System.out.println("Hamburgesas básicas: "+nHamBasica);
		System.out.println("Hamburgesas gourmet: "+nHamGourmet);
		System.out.println("Total: "+precioBase+" €");
		System.out.println("Descuento: "+descuento+" €");
		System.out.println("A pagar: "+precioFinal+" €");
		
	}
}
