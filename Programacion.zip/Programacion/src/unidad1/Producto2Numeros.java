package unidad1;

public class Producto2Numeros {
		public static void main(String[] args ) {
			float num1=8;
			float num2=10;
			float producto=num1*num2;
			
			System.out.println("El producto de "+num1+" y "+num2+" es: "+producto);

	}

}
