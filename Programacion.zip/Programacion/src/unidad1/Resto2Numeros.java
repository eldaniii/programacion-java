package unidad1;

public class Resto2Numeros {
		public static void main(String[] args ) {
			float num1=21;
			float num2=10;
			float resto=num1%num2;
			
			System.out.println("El resto de "+num1+" y "+num2+" es: "+resto);

	}
}
